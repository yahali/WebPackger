﻿namespace WebPackageTool
{
    partial class PackageControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxExceptDir = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxExceptExt = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.btnPackage = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxSrc = new System.Windows.Forms.TextBox();
            this.textBoxDest = new System.Windows.Forms.TextBox();
            this.dateTimePickerLastUpdate = new System.Windows.Forms.DateTimePicker();
            this.btnSaveAs = new System.Windows.Forms.Button();
            this.btnBrowSrc = new System.Windows.Forms.Button();
            this.btnBrowDest = new System.Windows.Forms.Button();
            this.txtSiteId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTheme = new System.Windows.Forms.TextBox();
            this.chkOnlyEditTime = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "模版名称：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 46);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "源文件目录：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 79);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "目标目录：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 158);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "上次更新时间：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxExceptDir);
            this.groupBox1.Location = new System.Drawing.Point(335, 54);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(309, 302);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "排除的目录";
            // 
            // textBoxExceptDir
            // 
            this.textBoxExceptDir.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxExceptDir.Location = new System.Drawing.Point(4, 22);
            this.textBoxExceptDir.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxExceptDir.Multiline = true;
            this.textBoxExceptDir.Name = "textBoxExceptDir";
            this.textBoxExceptDir.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxExceptDir.Size = new System.Drawing.Size(301, 276);
            this.textBoxExceptDir.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxExceptExt);
            this.groupBox2.Location = new System.Drawing.Point(16, 54);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(311, 302);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "排除的后缀名";
            // 
            // textBoxExceptExt
            // 
            this.textBoxExceptExt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxExceptExt.Location = new System.Drawing.Point(4, 22);
            this.textBoxExceptExt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxExceptExt.Multiline = true;
            this.textBoxExceptExt.Name = "textBoxExceptExt";
            this.textBoxExceptExt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxExceptExt.Size = new System.Drawing.Size(303, 276);
            this.textBoxExceptExt.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(5, 214);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(657, 364);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "打包设置";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(16, 26);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(114, 19);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "ASP.NET站点";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 29);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "网站编号：";
            // 
            // btnPackage
            // 
            this.btnPackage.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnPackage.Location = new System.Drawing.Point(349, 152);
            this.btnPackage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPackage.Name = "btnPackage";
            this.btnPackage.Size = new System.Drawing.Size(100, 29);
            this.btnPackage.TabIndex = 3;
            this.btnPackage.Text = "立即打包";
            this.btnPackage.UseVisualStyleBackColor = true;
            this.btnPackage.Click += new System.EventHandler(this.btnPackage_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(451, 152);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 29);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "存储模版";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(149, 8);
            this.textBoxName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.ReadOnly = true;
            this.textBoxName.Size = new System.Drawing.Size(513, 25);
            this.textBoxName.TabIndex = 4;
            // 
            // textBoxSrc
            // 
            this.textBoxSrc.Location = new System.Drawing.Point(148, 41);
            this.textBoxSrc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxSrc.Name = "textBoxSrc";
            this.textBoxSrc.Size = new System.Drawing.Size(453, 25);
            this.textBoxSrc.TabIndex = 4;
            // 
            // textBoxDest
            // 
            this.textBoxDest.Location = new System.Drawing.Point(148, 74);
            this.textBoxDest.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxDest.Name = "textBoxDest";
            this.textBoxDest.Size = new System.Drawing.Size(453, 25);
            this.textBoxDest.TabIndex = 4;
            // 
            // dateTimePickerLastUpdate
            // 
            this.dateTimePickerLastUpdate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.dateTimePickerLastUpdate.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dateTimePickerLastUpdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerLastUpdate.Location = new System.Drawing.Point(148, 154);
            this.dateTimePickerLastUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePickerLastUpdate.Name = "dateTimePickerLastUpdate";
            this.dateTimePickerLastUpdate.Size = new System.Drawing.Size(200, 25);
            this.dateTimePickerLastUpdate.TabIndex = 5;
            // 
            // btnSaveAs
            // 
            this.btnSaveAs.Location = new System.Drawing.Point(559, 152);
            this.btnSaveAs.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSaveAs.Name = "btnSaveAs";
            this.btnSaveAs.Size = new System.Drawing.Size(101, 29);
            this.btnSaveAs.TabIndex = 3;
            this.btnSaveAs.Text = "另存为模版";
            this.btnSaveAs.UseVisualStyleBackColor = true;
            this.btnSaveAs.Click += new System.EventHandler(this.btnSaveAs_Click);
            // 
            // btnBrowSrc
            // 
            this.btnBrowSrc.Location = new System.Drawing.Point(612, 39);
            this.btnBrowSrc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBrowSrc.Name = "btnBrowSrc";
            this.btnBrowSrc.Size = new System.Drawing.Size(51, 29);
            this.btnBrowSrc.TabIndex = 6;
            this.btnBrowSrc.Text = "…";
            this.btnBrowSrc.UseVisualStyleBackColor = true;
            this.btnBrowSrc.Click += new System.EventHandler(this.btnBrowSrc_Click);
            // 
            // btnBrowDest
            // 
            this.btnBrowDest.Location = new System.Drawing.Point(612, 72);
            this.btnBrowDest.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBrowDest.Name = "btnBrowDest";
            this.btnBrowDest.Size = new System.Drawing.Size(51, 29);
            this.btnBrowDest.TabIndex = 6;
            this.btnBrowDest.Text = "…";
            this.btnBrowDest.UseVisualStyleBackColor = true;
            this.btnBrowDest.Click += new System.EventHandler(this.btnBrowDest_Click);
            // 
            // txtSiteId
            // 
            this.txtSiteId.Location = new System.Drawing.Point(148, 114);
            this.txtSiteId.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSiteId.Name = "txtSiteId";
            this.txtSiteId.Size = new System.Drawing.Size(200, 25);
            this.txtSiteId.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 119);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "网站编号：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(363, 119);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "模板名称：";
            // 
            // txtTheme
            // 
            this.txtTheme.Location = new System.Drawing.Point(449, 112);
            this.txtTheme.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTheme.Name = "txtTheme";
            this.txtTheme.Size = new System.Drawing.Size(200, 25);
            this.txtTheme.TabIndex = 4;
            // 
            // chkOnlyEditTime
            // 
            this.chkOnlyEditTime.AutoSize = true;
            this.chkOnlyEditTime.Location = new System.Drawing.Point(148, 188);
            this.chkOnlyEditTime.Name = "chkOnlyEditTime";
            this.chkOnlyEditTime.Size = new System.Drawing.Size(104, 19);
            this.chkOnlyEditTime.TabIndex = 7;
            this.chkOnlyEditTime.Text = "仅更新时间";
            this.chkOnlyEditTime.UseVisualStyleBackColor = true;
            // 
            // PackageControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.chkOnlyEditTime);
            this.Controls.Add(this.btnBrowDest);
            this.Controls.Add(this.btnBrowSrc);
            this.Controls.Add(this.dateTimePickerLastUpdate);
            this.Controls.Add(this.txtTheme);
            this.Controls.Add(this.txtSiteId);
            this.Controls.Add(this.textBoxDest);
            this.Controls.Add(this.textBoxSrc);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.btnSaveAs);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnPackage);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox3);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "PackageControl";
            this.Size = new System.Drawing.Size(677, 610);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxExceptDir;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBoxExceptExt;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button btnPackage;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxSrc;
        private System.Windows.Forms.TextBox textBoxDest;
        private System.Windows.Forms.DateTimePicker dateTimePickerLastUpdate;
        private System.Windows.Forms.Button btnSaveAs;
        private System.Windows.Forms.Button btnBrowSrc;
        private System.Windows.Forms.Button btnBrowDest;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSiteId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTheme;
        private System.Windows.Forms.CheckBox chkOnlyEditTime;
    }
}
